WITH Faults AS
(
    SELECT
        machine,
        start_time,
        end_time,
        LEAD(start_time) OVER (
            PARTITION BY machine
            ORDER BY start_time
        ) AS next_fault_start
    FROM dbo.SubAssemblyFaultHistory
    WHERE machine = :equipment
        AND end_time IS NOT NULL
)
SELECT
    ROUND(
        AVG(
            DATEDIFF(SECOND, end_time, next_fault_start)
        ) / 60.0,
        2
    ) AS MTBF_Minutes
FROM Faults
WHERE next_fault_start IS NOT NULL
    AND next_fault_start > end_time;