WITH PartEvents AS (
    SELECT
        machine,
        datetime_input,

        LAG(datetime_input) OVER (
            PARTITION BY machine
            ORDER BY datetime_input
        ) AS previous_part_time

    FROM dbo.SubAssemblyProductionFeed

    WHERE operation = '110'
      AND feed = 'infeed'
      AND datetime_input >= :startDateTime
      AND datetime_input < :endDateTime
      AND (
            :selectedEquipment = 'All'
            OR machine = :selectedEquipment
          )
),

CycleTimes AS (
    SELECT
        DATEDIFF(
            SECOND,
            previous_part_time,
            datetime_input
        ) AS cycle_time_seconds

    FROM PartEvents

    WHERE previous_part_time IS NOT NULL
),

FilteredCycleTimes AS (
    SELECT cycle_time_seconds
    FROM CycleTimes
    WHERE cycle_time_seconds > 0
      AND cycle_time_seconds <= 60
      -- Filters long downtime events
)

SELECT

    CAST(
        AVG(
            CAST(cycle_time_seconds AS FLOAT)
        )
        AS DECIMAL(10,2)
    ) AS AvgCycleTimeSeconds,

    CAST(
        3600.0 /
        NULLIF(
            AVG(
                CAST(cycle_time_seconds AS FLOAT)
            ),
            0
        )
        AS DECIMAL(10,2)
    ) AS AvgPartsPerHour

FROM FilteredCycleTimes;