INSERT INTO dbo.SubAssemblyFaultHistory
(
    machine,
    fault_message,
    start_time,
    end_time,
    active
)
VALUES
(
    :machine,
    :faultMessage,
    :startTime,
    NULL,
    1
);