INSERT INTO SubAssemblyProductionFeed (
	datetime_input,
	machine,
	operation,
	product_code,
	feed
)
VALUES (
	:datetime_input,
	:machine,
	:operation,
	:product_code,
	:feed
);