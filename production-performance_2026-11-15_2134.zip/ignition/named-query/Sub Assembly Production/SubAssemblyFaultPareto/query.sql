WITH FaultData AS (
    SELECT
        fault_message,
        COUNT(*) AS Occurrences,
        ROUND(
            SUM(
                DATEDIFF(SECOND, start_time, ISNULL(end_time, GETDATE()))
            ) / 60.0,
            2
        ) AS TotalDowntimeMinutes
    FROM SubAssemblyFaultHistory
    WHERE
        (:equipment = 'All'
         OR machine = :equipment)
    GROUP BY fault_message
)

SELECT
    fault_message,
    CASE
        WHEN :analysisMetric = 'occurrence'
            THEN Occurrences
        WHEN :analysisMetric = 'duration'
            THEN TotalDowntimeMinutes
    END AS Value
FROM FaultData
ORDER BY
    CASE
        WHEN :analysisMetric = 'occurrence'
            THEN Occurrences
        WHEN :analysisMetric = 'duration'
            THEN TotalDowntimeMinutes
    END DESC;