WITH ProductionData AS (
    SELECT
        product_code,
        datetime_input,
        operation,
        feed
    FROM dbo.SubAssemblyProductionFeed
    WHERE datetime_input >= :startDateTime
      AND datetime_input < :endDateTime
      AND (
            :selectedEquipment = 'All'
            OR machine = :selectedEquipment
          )
),

Counts AS (
    SELECT
        product_code,

        MAX(datetime_input) AS LastProduced,

        SUM(
            CASE
                WHEN operation = '110'
                 AND feed = 'infeed'
                THEN 1
                ELSE 0
            END
        ) AS InfeedCount,

        SUM(
            CASE
                WHEN operation = '140'
                 AND feed = 'outfeed'
                THEN 1
                ELSE 0
            END
        ) AS CompletedParts

    FROM ProductionData
    GROUP BY product_code
),

CycleIntervals AS (
    SELECT
        product_code,

        DATEDIFF(
            SECOND,
            LAG(datetime_input) OVER (
                PARTITION BY product_code
                ORDER BY datetime_input
            ),
            datetime_input
        ) AS IntervalSeconds

    FROM ProductionData
    WHERE operation = '140'
      AND feed = 'outfeed'
),

PPH AS (
    SELECT
        product_code,

        CAST(
            3600.0 /
            NULLIF(
                AVG(
                    CAST(IntervalSeconds AS FLOAT)
                ),
                0
            )
            AS DECIMAL(10,2)
        ) AS AvgPartsPerHour

    FROM CycleIntervals

    WHERE IntervalSeconds > 0
      AND IntervalSeconds <= 60

    GROUP BY product_code
)

SELECT
    c.product_code AS ModelNumber,
    c.LastProduced,
    c.InfeedCount,
    c.CompletedParts,
    ISNULL(pph.AvgPartsPerHour, 0) AS AvgPartsPerHour

FROM Counts c
LEFT JOIN PPH pph
    ON c.product_code = pph.product_code

ORDER BY c.LastProduced DESC;