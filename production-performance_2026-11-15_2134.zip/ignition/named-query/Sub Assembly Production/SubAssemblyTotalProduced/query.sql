WITH ProductionSummary AS (
    SELECT
      SUM(CASE WHEN operation = '110' AND feed = 'infeed' THEN 1 ELSE 0 END) AS InfeedCount,
      SUM(CASE WHEN operation = '140' AND feed = 'outfeed' THEN 1 ELSE 0 END) AS OutfeedCount
    FROM dbo.SubAssemblyProductionFeed
    WHERE datetime_input >= :startDateTime
      AND datetime_input < :endDateTime
      AND (
            :selectedEquipment = 'All'
            OR machine = :selectedEquipment
          )
)

SELECT
    OutfeedCount AS TotalProduced,
    InfeedCount,
    OutfeedCount
FROM ProductionSummary;