WITH Cycles AS
(
    SELECT
        operation,
        DATEDIFF(
            MILLISECOND,
            LAG(datetime_input) OVER(
                PARTITION BY operation
                ORDER BY datetime_input
            ),
            datetime_input
        ) / 1000.0 AS CycleSeconds
    FROM BWC_Trace.dbo.SubAssemblyProductionFeed
    WHERE machine = :equipment
      AND feed = 'outfeed'
      AND datetime_input BETWEEN :startDateTime AND :endDateTime
)
SELECT
    ROUND(AVG(CASE WHEN operation = 110 THEN CycleSeconds END), 2) AS Op110Avg,
    ROUND(AVG(CASE WHEN operation = 120 THEN CycleSeconds END), 2) AS Op120Avg,
    ROUND(AVG(CASE WHEN operation = 130 THEN CycleSeconds END), 2) AS Op130Avg,
    ROUND(AVG(CASE WHEN operation = 140 THEN CycleSeconds END), 2) AS Op140Avg
FROM Cycles
WHERE CycleSeconds BETWEEN 1 AND 50;