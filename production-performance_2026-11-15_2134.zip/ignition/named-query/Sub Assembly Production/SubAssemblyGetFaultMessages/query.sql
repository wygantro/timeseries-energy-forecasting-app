SELECT TOP 50
    start_time AS eventTime,
    fault_message AS faultMessage,
    CONVERT(VARCHAR(8),
        DATEADD(SECOND,
            DATEDIFF(SECOND, start_time, end_time),
            0),
        108) AS duration
FROM dbo.SubAssemblyFaultHistory
WHERE machine = :machineName
    AND active = 0
    AND end_time IS NOT NULL
ORDER BY start_time DESC;