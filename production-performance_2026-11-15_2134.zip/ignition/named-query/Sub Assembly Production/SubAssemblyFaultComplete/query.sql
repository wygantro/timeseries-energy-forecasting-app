UPDATE dbo.SubAssemblyFaultHistory
SET
    end_time = :endTime,
    active = 0
WHERE machine = :machine
    AND active = 1;