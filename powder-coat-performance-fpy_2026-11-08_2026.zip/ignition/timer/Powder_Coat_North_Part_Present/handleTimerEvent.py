def handleTimerEvent():
	from java.lang import System
	
	
	# ------------------------------------------------------------
	# Tag path
	# ------------------------------------------------------------
	
	PART_PRESENT_TAG = "[default]Powder Coat Test/North Booth/part_present"
	
	
	# ------------------------------------------------------------
	# Get position within 5-second cycle
	# ------------------------------------------------------------
	
	now = System.currentTimeMillis()
	
	cyclePosition = now % 5000
	
	
	# ------------------------------------------------------------
	# Part is present for first 2 seconds
	# ------------------------------------------------------------
	
	if cyclePosition < 3000:
	
	    system.tag.writeBlocking(
	        [PART_PRESENT_TAG],
	        [True]
	    )
	
	else:
	
	    system.tag.writeBlocking(
	        [PART_PRESENT_TAG],
	        [False]
	    )