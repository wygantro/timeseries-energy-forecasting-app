def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	from java.lang import Thread
		
	if not previousValue.value and currentValue.value:
		logger = system.util.getLogger("PowderCoatFPY")
		logger.info("Tag change detected")
		
		# Wait 0.1 seconds for tag values to stabilize
		Thread.sleep(100)
		
		# Tag paths
		BOOTH_TAG = "[default]Powder Coat Test/South Booth/booth"
		RESPRAY_TAG = "[default]Powder Coat Test/South Booth/respray"
		RECIPE_TAG = "[default]Powder Coat Test/South Booth/part_recipe"
		
		# Read tag values
		tagPaths = [
		    BOOTH_TAG,
		    RESPRAY_TAG,
		    RECIPE_TAG
		]
		
		values = system.tag.readBlocking(tagPaths)
		
		booth = values[0].value
		respray = values[1].value
		recipe = values[2].value
		
		logger.info(
		    "Part data - Booth: %s, Respray: %s, Recipe: %s"
		    % (booth, respray, recipe)
		)
		
		# Named Query parameters
		params = {
		    "booth": booth,
		    "respray": respray,
		    "recipe": recipe
		}
		
		# Insert record
		try:
		    system.db.runNamedQuery(
		        "insert_powder_coat_part_record",
		        params
		    )
		
		    logger.info("South powder coat part record inserted successfully")
		
		except Exception as e:
		    logger.error("Failed to insert powder coat part record: %s" % str(e))