def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	import random
	
	
	# ------------------------------------------------------------
	# Part arrived
	# ------------------------------------------------------------
	
	if currentValue.value and not previousValue.value:
	
	    # Generate one recipe for this part
	    recipe = random.randint(1, 10)
	
	    # Determine respray once for this part
	    respray = random.random() < 0.28
	
	    # Write both values
	    system.tag.writeBlocking(
	        [
	            "[default]Powder Coat Test/South Booth/part_recipe",
	            "[default]Powder Coat Test/South Booth/respray"
	        ],
	        [
	            recipe,
	            respray
	        ]
	    )
	
	
	# ------------------------------------------------------------
	# Part left
	# ------------------------------------------------------------
	
	elif not currentValue.value and previousValue.value:
	
	    # Turn respray OFF when part leaves
	    system.tag.writeBlocking(
	        [
	            "[default]Powder Coat Test/South Booth/respray"
	        ],
	        [
	            False
	        ]
	    )