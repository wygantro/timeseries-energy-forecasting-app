INSERT INTO powder_coat_fpy_records (
	datetime,
	booth,
	respray,
	recipe
	)
VALUES (
	NOW(),
	:booth,
	:respray,
	:recipe
);