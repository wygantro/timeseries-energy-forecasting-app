WITH settings AS (
    SELECT
        CAST(:selectedTime AS integer) AS selected_time,
        LOWER(CAST(:selectedBooth AS text)) AS selected_booth
),

recipe_counts AS (
    SELECT
        p.recipe,
        COUNT(*) AS part_count
    FROM powder_coat_fpy_records p
    CROSS JOIN settings s
    WHERE
        p.datetime >= CURRENT_TIMESTAMP
            - make_interval(mins => s.selected_time)

        AND (
            s.selected_booth = 'both'
            OR LOWER(p.booth) = s.selected_booth
        )

        AND p.recipe IS NOT NULL

    GROUP BY p.recipe
),

ranked AS (
    SELECT
        recipe,
        part_count,
        SUM(part_count) OVER () AS total_parts,
        SUM(part_count) OVER (
            ORDER BY part_count DESC, recipe
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS cumulative_parts
    FROM recipe_counts
)

SELECT
    recipe,
    part_count,

    ROUND(
        part_count::numeric
        / NULLIF(total_parts, 0) * 100,
        1
    ) AS percentage,

    ROUND(
        cumulative_parts::numeric
        / NULLIF(total_parts, 0) * 100,
        1
    ) AS cumulative_percentage

FROM ranked

ORDER BY
    part_count DESC,
    recipe;