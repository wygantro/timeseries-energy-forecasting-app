SELECT
    COUNT(*) AS total_parts,

    COUNT(*) FILTER (
        WHERE respray = FALSE
    ) AS total_good,

    COUNT(*) FILTER (
        WHERE respray = TRUE
    ) AS total_bad,

    ROUND(
        (
            COUNT(*) FILTER (WHERE respray = FALSE)::numeric
            / NULLIF(COUNT(*), 0)
        ) * 100,
        1
    ) AS fpy_percentage

FROM powder_coat_fpy_records

WHERE datetime >= CURRENT_TIMESTAMP - (:selectedTime * INTERVAL '1 minute')

  AND (
      LOWER(:selectedBooth) = 'both'
      OR LOWER(booth) = LOWER(:selectedBooth)
  );