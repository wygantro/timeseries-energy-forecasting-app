WITH settings AS (
    SELECT
        :selectedTime::integer AS selected_time,
        LOWER(:selectedBooth::text) AS selected_booth
),

config AS (
    SELECT
        selected_time,
        selected_booth,

        CASE
            WHEN selected_time <= 15    THEN 1
            WHEN selected_time <= 30    THEN 2
            WHEN selected_time <= 60    THEN 5
            WHEN selected_time <= 240   THEN 15
            WHEN selected_time <= 480   THEN 30
            WHEN selected_time <= 1440  THEN 60
            WHEN selected_time <= 10080 THEN 360
            ELSE 1440
        END AS bucket_minutes

    FROM settings
),

bucketed AS (
    SELECT
        date_bin(
            make_interval(mins => c.bucket_minutes),
            p.datetime,
            TIMESTAMP '2000-01-01'
        ) AS time_bucket,

        p.respray

    FROM powder_coat_fpy_records p
    CROSS JOIN config c

    WHERE
        p.datetime >= CURRENT_TIMESTAMP
            - make_interval(mins => c.selected_time)

        AND (
            c.selected_booth = 'both'
            OR LOWER(p.booth) = c.selected_booth
        )
)

SELECT
    time_bucket,

    ROUND(
        COUNT(*) FILTER (WHERE respray = FALSE)::numeric
        / NULLIF(COUNT(*), 0) * 100,
        1
    ) AS fpy_percentage

FROM bucketed

GROUP BY time_bucket

ORDER BY time_bucket ASC;